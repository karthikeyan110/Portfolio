import Hero from "@/components/hero"
import SocialApps from "@/components/social-apps"
import About from "@/components/about"
import Services from "@/components/services"
import Projects from "@/components/projects"
import Contact from "@/components/contact"
import Header from "@/components/header"
import CustomCursor from "@/components/custom-cursor"
import ScrollProgress from "@/components/scroll-progress"
import ParticleBackground from "@/components/particle-background"

export default function Home() {
  return (
    <main className="bg-black text-white overflow-x-hidden">
      <ParticleBackground />
      <CustomCursor />
      <ScrollProgress />
      <Header />
      <Hero />
      <SocialApps />
      <About />
      <Services />
      <Projects />
      <Contact />
      <footer className="text-center py-10 border-t border-white/10 text-gray-500">
        <p>&copy; 2025 Karthikeyan Pandita. All rights reserved. Crafted with passion and coffee ☕</p>
      </footer>
    </main>
  )
}
