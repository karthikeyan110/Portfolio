"use client"

export default function About() {
  return (
    <section id="about" className="py-32 px-4 max-w-7xl mx-auto relative z-10">
      <h2 className="text-5xl font-bold text-center mb-20 relative">
        About Me
        <div className="absolute -bottom-5 left-1/2 transform -translate-x-1/2 w-15 h-1 bg-red-400" />
      </h2>

      <div className="grid lg:grid-cols-2 gap-20 items-center">
        <div className="space-y-6">
          <h3 className="text-2xl font-semibold mb-5"></h3>
          <p className="text-lg text-gray-300 leading-relaxed">
            I am a passionate Data Science student with a strong interest in turning raw data into actionable insights.
            With hands-on experience in Python, SQL, machine learning, and data visualization tools like Tableau and
            Matplotlib, I enjoy solving real-world problems using data. I've worked on projects involving predictive
            modeling, recommendation systems, and exploratory data analysis, and I'm constantly expanding my knowledge
            in areas like NLP, AI, and deep learning.
          </p>
          <p className="text-lg text-gray-300 leading-relaxed">
            My goal is to use data to drive smarter decisions and create impactful solutions. I'm currently looking for
            internship opportunities where I can apply my skills, learn from industry experts, and contribute
            meaningfully to data-driven projects.
          </p>
        </div>

        <div className="relative">
          <div className="w-full h-[500px] bg-gradient-to-br from-red-400 to-cyan-400 rounded-3xl flex items-center justify-center text-8xl relative overflow-hidden">
            👨‍🎨
            <div className="absolute inset-0">
              <div className="absolute w-15 h-15 bg-white/20 rounded-full top-1/4 left-1/4 animate-float" />
              <div className="absolute w-10 h-10 bg-white/20 rounded-full top-3/5 right-1/4 animate-float animation-delay-2000" />
              <div className="absolute w-20 h-20 bg-white/20 rounded-full bottom-1/4 left-1/3 animate-float animation-delay-4000" />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
