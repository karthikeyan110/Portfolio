const contactLinks = [
  { icon: "📧", label: "Email Me", href: "mailto:110karthikeyan@gmail.com" },
  { icon: "💼", label: "LinkedIn", href: "https://linkedin.com/in/karthikeyan-pandita-900a7a287" },
  { icon: "🐦", label: "Twitter", href: "#" },
]

export default function Contact() {
  return (
    <section id="contact" className="py-32 px-4 max-w-4xl mx-auto text-center relative z-10">
      <h2 className="text-5xl font-bold mb-20 relative">
        Let's Work Together
        <div className="absolute -bottom-5 left-1/2 transform -translate-x-1/2 w-15 h-1 bg-red-400" />
      </h2>

      <p className="text-xl text-gray-400 mb-12 leading-relaxed">
        Ready to bring your ideas to life? I'm always excited to work on new projects and collaborate with amazing
        people and brands.
      </p>

      <div className="flex flex-wrap justify-center gap-6">
        {contactLinks.map((link) => (
          <a
            key={link.label}
            href={link.href}
            className="flex items-center gap-3 px-8 py-4 bg-white/5 border border-white/20 rounded-full transition-all duration-300 hover:bg-red-400/10 hover:border-red-400/30 hover:transform hover:-translate-y-1"
          >
            <span className="text-xl">{link.icon}</span>
            {link.label}
          </a>
        ))}
      </div>
    </section>
  )
}
