const projects = [
  {
    icon: "🏦",
    title: "FinTech Banking App",
    description:
      "A comprehensive mobile banking solution with intuitive navigation and secure transaction flows, serving over 100k users.",
    tags: ["UI Design", "UX Research", "Prototyping", "Mobile"],
  },
  {
    icon: "🛍️",
    title: "E-Commerce Platform",
    description:
      "Modern e-commerce experience with personalized recommendations and streamlined checkout process increasing conversion by 35%.",
    tags: ["Web Design", "User Testing", "Conversion", "Analytics"],
  },
  {
    icon: "✈️",
    title: "Flight reservation system",
    description:
      "A user-friendly Flight Reservation System built with Java and MySQL that allows users to search, book, and manage flight tickets.The system supports real-time seat availability, passenger details management, and secure booking confirmation..",
    tags: ["Python", "Web Design", "AI/ML", ],
  },
]

export default function Projects() {
  return (
    <section id="projects" className="py-32 px-4 max-w-7xl mx-auto relative z-10">
      <h2 className="text-5xl font-bold text-center mb-20 relative">
        Featured Projects
        <div className="absolute -bottom-5 left-1/2 transform -translate-x-1/2 w-15 h-1 bg-red-400" />
      </h2>

      <div className="grid lg:grid-cols-3 gap-10">
        {projects.map((project, index) => (
          <div
            key={project.title}
            className="group bg-white/5 rounded-3xl border border-white/10 overflow-hidden transition-all duration-300 hover:transform hover:-translate-y-3 hover:shadow-2xl hover:shadow-black/30"
          >
            <div className="h-64 bg-gradient-to-br from-red-400 via-cyan-400 to-blue-500 flex items-center justify-center text-6xl relative overflow-hidden">
              {project.icon}
              <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <button className="px-6 py-3 bg-red-400 text-white rounded-full font-semibold hover:bg-red-500 transition-colors">
                  View Project
                </button>
              </div>
            </div>
            <div className="p-8">
              <h3 className="text-xl font-semibold mb-4">{project.title}</h3>
              <p className="text-gray-400 mb-6 leading-relaxed">{project.description}</p>
              <div className="flex flex-wrap gap-2">
                {project.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 bg-red-400/20 text-red-400 rounded-full text-sm border border-red-400/30"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
