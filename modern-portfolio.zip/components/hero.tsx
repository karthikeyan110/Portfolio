"use client"

import { useEffect, useState } from "react"

export default function Hero() {
  const [displayText, setDisplayText] = useState("")
  const fullText = "Karthikeyan Pandita"

  useEffect(() => {
    let i = 0
    const timer = setInterval(() => {
      if (i < fullText.length) {
        setDisplayText(fullText.slice(0, i + 1))
        i++
      } else {
        clearInterval(timer)
      }
    }, 150)

    return () => clearInterval(timer)
  }, [])

  return (
    <section id="home" className="min-h-screen flex items-center justify-center text-center relative">
      <div
        className="absolute inset-0 bg-gradient-radial from-red-400/10 via-transparent to-transparent"
        style={{
          background: "radial-gradient(ellipse at center, rgba(239, 68, 68, 0.1) 0%, transparent 50%)",
        }}
      />
      <div className="max-w-4xl mx-auto px-4 relative z-10">
        <div className="text-red-400 text-sm tracking-[3px] uppercase mb-5 animate-fade-in-up">Web Developer</div>
        <h1 className="text-6xl md:text-8xl font-extrabold mb-8 bg-gradient-to-r from-white to-red-400 bg-clip-text text-transparent animate-fade-in-up animation-delay-200">
          {displayText}
          <span className="animate-pulse">|</span>
        </h1>
        <p className="text-xl text-gray-400 mb-12 max-w-2xl mx-auto leading-relaxed animate-fade-in-up animation-delay-400">
          Aspiring Data Scientist with a strong foundation in statistics, machine learning, and data visualization.
          Passionate about solving real-world problems using data-driven insights..
        </p>
        <button
          onClick={() => document.getElementById("social-apps")?.scrollIntoView({ behavior: "smooth" })}
          className="group relative px-10 py-4 bg-red-400 text-white rounded-full font-semibold transition-all duration-300 hover:transform hover:-translate-y-1 hover:shadow-2xl hover:shadow-red-400/30 animate-fade-in-up animation-delay-600 overflow-hidden"
        >
          <span className="relative z-10">View My Work</span>
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-500" />
        </button>
      </div>
    </section>
  )
}
