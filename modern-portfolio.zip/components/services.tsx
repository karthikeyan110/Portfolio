const skills = [
  {
    icon: "🤖",
    title: "AI/ML",
    description:
      "Machine learning algorithms, neural networks, and artificial intelligence solutions for data-driven insights.",
    color: "from-purple-500 to-pink-500",
  },
  {
    icon: "🐍",
    title: "Python",
    description:
      "Data analysis, web development, automation, and machine learning using Python frameworks and libraries.",
    color: "from-blue-500 to-green-500",
  },
  {
    icon: "☕",
    title: "Java",
    description: "Object-oriented programming, enterprise applications, and robust backend development solutions.",
    color: "from-orange-500 to-red-500",
  },
  {
    icon: "🐧",
    title: "Linux",
    description: "System administration, command line proficiency, and server management in Linux environments.",
    color: "from-gray-600 to-gray-800",
  },
  {
    icon: "⚡",
    title: "C",
    description: "Low-level programming, system programming, and performance-critical application development.",
    color: "from-blue-600 to-purple-600",
  },
  {
    icon: "🔧",
    title: "C++",
    description: "Advanced programming concepts, game development, and high-performance computing applications.",
    color: "from-indigo-500 to-blue-600",
  },
  {
    icon: "🌐",
    title: "HTML",
    description: "Semantic markup, web structure, and modern HTML5 features for responsive web development.",
    color: "from-orange-400 to-red-500",
  },
  {
    icon: "🎨",
    title: "CSS",
    description: "Responsive design, animations, and modern CSS frameworks for beautiful user interfaces.",
    color: "from-cyan-400 to-blue-500",
  },
]

export default function Services() {
  return (
    <section id="services" className="py-32 px-4 max-w-7xl mx-auto relative z-10">
      <h2 className="text-5xl font-bold text-center mb-20 relative">
        Technical Skills
        <div className="absolute -bottom-5 left-1/2 transform -translate-x-1/2 w-15 h-1 bg-red-400" />
      </h2>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {skills.map((skill, index) => (
          <div
            key={skill.title}
            className="group p-8 bg-white/5 rounded-3xl border border-white/10 transition-all duration-300 hover:transform hover:-translate-y-3 hover:bg-red-400/10 hover:border-red-400/30 relative overflow-hidden"
          >
            <div
              className={`w-20 h-20 bg-gradient-to-br ${skill.color} rounded-2xl flex items-center justify-center text-3xl mb-6 group-hover:scale-110 transition-transform duration-300`}
            >
              {skill.icon}
            </div>
            <h3 className="text-xl font-semibold mb-4 group-hover:text-red-400 transition-colors duration-300">
              {skill.title}
            </h3>
            <p className="text-gray-400 leading-relaxed text-sm group-hover:text-gray-300 transition-colors duration-300">
              {skill.description}
            </p>

            {/* Skill level indicator */}
            <div className="mt-6">
              <div className="w-full bg-gray-700 rounded-full h-2">
                <div
                  className={`bg-gradient-to-r ${skill.color} h-2 rounded-full transition-all duration-1000 group-hover:w-full`}
                  style={{ width: `${Math.floor(Math.random() * 30) + 70}%` }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}
